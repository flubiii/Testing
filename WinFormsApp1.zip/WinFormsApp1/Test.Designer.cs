﻿namespace WinFormsApp1
{
    partial class Test
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Test));
            Logo = new PictureBox();
            BackImage = new PictureBox();
            panel1 = new Panel();
            PasswordIcon = new PictureBox();
            LoginIcon = new PictureBox();
            buttonRegister = new Button();
            PasswordText = new TextBox();
            LoginText = new TextBox();
            buttonLogin = new Button();
            Help = new ToolTip(components);
            ((System.ComponentModel.ISupportInitialize)Logo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BackImage).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PasswordIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)LoginIcon).BeginInit();
            SuspendLayout();
            // 
            // Logo
            // 
            resources.ApplyResources(Logo, "Logo");
            Logo.Name = "Logo";
            Logo.TabStop = false;
            Help.SetToolTip(Logo, resources.GetString("Logo.ToolTip"));
            // 
            // BackImage
            // 
            resources.ApplyResources(BackImage, "BackImage");
            BackImage.BackColor = SystemColors.GradientActiveCaption;
            BackImage.Name = "BackImage";
            BackImage.TabStop = false;
            Help.SetToolTip(BackImage, resources.GetString("BackImage.ToolTip"));
            // 
            // panel1
            // 
            resources.ApplyResources(panel1, "panel1");
            panel1.Controls.Add(PasswordIcon);
            panel1.Controls.Add(LoginIcon);
            panel1.Controls.Add(buttonRegister);
            panel1.Controls.Add(PasswordText);
            panel1.Controls.Add(LoginText);
            panel1.Controls.Add(buttonLogin);
            panel1.Controls.Add(Logo);
            panel1.Name = "panel1";
            Help.SetToolTip(panel1, resources.GetString("panel1.ToolTip"));
            // 
            // PasswordIcon
            // 
            resources.ApplyResources(PasswordIcon, "PasswordIcon");
            PasswordIcon.Name = "PasswordIcon";
            PasswordIcon.TabStop = false;
            Help.SetToolTip(PasswordIcon, resources.GetString("PasswordIcon.ToolTip"));
            // 
            // LoginIcon
            // 
            resources.ApplyResources(LoginIcon, "LoginIcon");
            LoginIcon.Name = "LoginIcon";
            LoginIcon.TabStop = false;
            Help.SetToolTip(LoginIcon, resources.GetString("LoginIcon.ToolTip"));
            // 
            // buttonRegister
            // 
            resources.ApplyResources(buttonRegister, "buttonRegister");
            buttonRegister.BackColor = Color.Transparent;
            buttonRegister.FlatAppearance.BorderColor = Color.Silver;
            buttonRegister.Name = "buttonRegister";
            Help.SetToolTip(buttonRegister, resources.GetString("buttonRegister.ToolTip"));
            buttonRegister.UseVisualStyleBackColor = false;
            buttonRegister.Click += buttonRegister_Click;
            // 
            // PasswordText
            // 
            resources.ApplyResources(PasswordText, "PasswordText");
            PasswordText.Name = "PasswordText";
            Help.SetToolTip(PasswordText, resources.GetString("PasswordText.ToolTip"));
            PasswordText.UseSystemPasswordChar = true;
            PasswordText.Enter += PasswordText_Enter;
            PasswordText.Leave += PasswordText_Leave;
            // 
            // LoginText
            // 
            resources.ApplyResources(LoginText, "LoginText");
            LoginText.Name = "LoginText";
            Help.SetToolTip(LoginText, resources.GetString("LoginText.ToolTip"));
            LoginText.Enter += LoginText_Enter;
            // 
            // buttonLogin
            // 
            resources.ApplyResources(buttonLogin, "buttonLogin");
            buttonLogin.BackColor = Color.CornflowerBlue;
            buttonLogin.FlatAppearance.BorderColor = Color.Silver;
            buttonLogin.FlatAppearance.BorderSize = 0;
            buttonLogin.Name = "buttonLogin";
            Help.SetToolTip(buttonLogin, resources.GetString("buttonLogin.ToolTip"));
            buttonLogin.UseVisualStyleBackColor = false;
            buttonLogin.Click += button1_Click_1;
            // 
            // Help
            // 
            Help.AutoPopDelay = 5000;
            Help.InitialDelay = 100;
            Help.IsBalloon = true;
            Help.ReshowDelay = 100;
            Help.ShowAlways = true;
            // 
            // Test
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.None;
            Controls.Add(panel1);
            Controls.Add(BackImage);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "Test";
            Help.SetToolTip(this, resources.GetString("$this.ToolTip"));
            ((System.ComponentModel.ISupportInitialize)Logo).EndInit();
            ((System.ComponentModel.ISupportInitialize)BackImage).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PasswordIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)LoginIcon).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private PictureBox Logo;
        private PictureBox BackImage;
        private Panel panel1;
        private Button buttonLogin;
        private TextBox LoginText;
        private TextBox PasswordText;
        private Button buttonRegister;
        private PictureBox LoginIcon;
        private PictureBox PasswordIcon;
        private ToolTip Help;
        private Button Admin;
    }
}
