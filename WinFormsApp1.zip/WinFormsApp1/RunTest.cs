﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;

namespace WinFormsApp1
{
    public partial class RunTest : Form
    {
        private List<Question> questions = new List<Question>();
        private int currentQuestionIndex = 0;
        private int totalQuestions;
        private int score = 0;
        private Panel Quest;

        private int _testId;
        private int userId;
        public RunTest(int testId, string testName, string subject, int questionCount, int userId)
        {
            this.userId = userId;
            _testId = testId;
            totalQuestions = questionCount;

            InitializeComponent();
            LoadTestInfo(testId, testName, subject, questionCount);
            InitializeInstructionTest(testId);
            CreateTestPanel();

            this.ReturnButton.Click += new System.EventHandler(this.ReturnButton_Click);
        }

        private void CreateTestPanel()
        {
            Quest = new Panel
            {
                Location = new Point(15, 99),
                Size = new Size(1044, 562),
                AutoScroll = false

            };
            this.Controls.Add(Quest);
        }

        private void LoadTestInfo(int testId, string testName, string subject, int questionCount)
        {
            Label testNameLabel = new Label() { Text = "Название теста", AutoSize = true, Location = new Point(43, 26) };
            TextBox testNameTextBox = new TextBox() { Text = testName, Width = 355, Height = 20, Location = new Point(43, 44), ReadOnly = true, };
            Label subjectLabel = new Label() { Text = "Тема теста", AutoSize = true, Location = new Point(424, 26) };
            TextBox subjectTextBox = new TextBox() { Text = subject, Width = 250, Height = 20, Location = new Point(424, 44), ReadOnly = true };
            Label questionCountLabel = new Label() { Text = "Количество вопросов", AutoSize = true, Location = new Point(700, 26) };
            TextBox questionCountTextBox = new TextBox() { Text = questionCount.ToString(), Width = 150, Height = 20, Location = new Point(700, 44), ReadOnly = true };

            Info.Controls.Add(testNameLabel);
            Info.Controls.Add(testNameTextBox);
            Info.Controls.Add(subjectLabel);
            Info.Controls.Add(subjectTextBox);
            Info.Controls.Add(questionCountLabel);
            Info.Controls.Add(questionCountTextBox);
        }

        private void StartTestButton_Click(object sender, EventArgs e)
        {
            Tests.Controls.Clear();

            LoadQuestions(_testId);

            DisplayCurrentQuestion();

            Quest.BringToFront();
        }
        private void InitializeInstructionTest(int testId)
        {
            GroupBox instructionGroupBox1 = new GroupBox();
            instructionGroupBox1.Text = "Инструкции по прохождению теста";
            instructionGroupBox1.Size = new Size(1000, 40);
            instructionGroupBox1.Location = new Point(10, 10);
            instructionGroupBox1.Font = new System.Drawing.Font(instructionGroupBox1.Font.FontFamily, instructionGroupBox1.Font.Size, FontStyle.Bold);

            Label instructionLabel1 = new Label();
            instructionLabel1.Text = "Добро пожаловать в тест! Пожалуйста, внимательно прочитайте следующие инструкции перед началом.";
            instructionLabel1.AutoSize = true;
            instructionLabel1.Location = new Point(10, 20);

            instructionGroupBox1.Controls.Add(instructionLabel1);

            GroupBox instructionGroupBox2 = new GroupBox();
            instructionGroupBox2.Text = "Время и типы вопросов";
            instructionGroupBox2.Size = new Size(1000, 115);
            instructionGroupBox2.Location = new Point(10, 80);

            Label instructionLabel2 = new Label();
            instructionLabel2.Text = "• Время прохождения теста: Время не ограничено. Вы можете проходить тест в удобном для вас темпе. Однако старайтесь не затягивать с ответами, чтобы сохранить фокус и \n" +
                "эффективность.\n" +
                                     "• Типы вопросов: Тест состоит из различных типов вопросов, включая:\n" +
                                     "1. Один ответ: Выберите один правильный ответ из предложенных вариантов.\n" +
                                     "2. Несколько ответов: Выберите все правильные ответы из предложенных вариантов.\n" +
                                     "3. Последовательность: Упорядочите элементы в правильной последовательности.";
            instructionLabel2.AutoSize = true;
            instructionLabel2.Location = new Point(10, 20);

            instructionGroupBox2.Controls.Add(instructionLabel2);

            GroupBox instructionGroupBox3 = new GroupBox();
            instructionGroupBox3.Text = "Завершение теста";
            instructionGroupBox3.Size = new Size(1000, 55);
            instructionGroupBox3.Location = new Point(10, 220);

            Label instructionLabel3 = new Label();
            instructionLabel3.Text = "• После того как вы ответите на все вопросы, нажмите на кнопку 'Закончить тест', чтобы отправить свои ответы на проверку.\n" +
                                     "Желаем удачи в прохождении теста!";
            instructionLabel3.AutoSize = true;
            instructionLabel3.Location = new Point(10, 20);

            instructionGroupBox3.Controls.Add(instructionLabel3);

            Button startTestButton = new Button();
            startTestButton.Text = "Начать тест";
            startTestButton.Location = new Point(10, 305);
            startTestButton.Click += new EventHandler(StartTestButton_Click);

            Tests.Controls.Add(instructionGroupBox1);
            Tests.Controls.Add(instructionGroupBox2);
            Tests.Controls.Add(instructionGroupBox3);
            Tests.Controls.Add(startTestButton);
        }

        public class Question
        {
            public string QuestionText { get; set; }
            public int QuestionID { get; set; }
            public List<Answer> Answers { get; set; } = new List<Answer>();
            public QuestionType QuestionType { get; set; }
            public Image Image { get; set; }
        }

        public enum QuestionType
        {
            SingleChoice,
            MultipleChoice,
            Sequence
        }
        public class Answer
        {
            public int AnswerID { get; set; }
            public int QuestionID { get; set; }
            public string AnswerText { get; set; }
            public bool IsCorrect { get; set; }
        }

        private QuestionType? GetQuestionTypeFromString(string questionTypeString)
        {
            return questionTypeString switch
            {
                "Один ответ" => QuestionType.SingleChoice,
                "Несколько ответов" => QuestionType.MultipleChoice,
                "Последовательность ответов" => QuestionType.Sequence,
                _ => null
            };
        }

        private void LoadQuestions(int testId)
        {
            using (DB db = new DB())
            {
                try
                {
                    db.OpenConnection();

                    string queryQuestions = "SELECT * FROM Questions WHERE TestID = @TestID";
                    SqlCommand command = new SqlCommand(queryQuestions, db.GetConnection());
                    command.Parameters.AddWithValue("@TestID", testId);

                    SqlDataReader reader = command.ExecuteReader();

                    questions.Clear();

                    while (reader.Read())
                    {
                        if (reader["QuestionText"] != DBNull.Value && reader["QuestionType"] != DBNull.Value)
                        {
                            Question question = new Question
                            {
                                QuestionText = reader["QuestionText"].ToString(),
                                QuestionID = (int)reader["QuestionID"]
                            };

                            string questionTypeString = reader["QuestionType"].ToString();
                            var questionType = GetQuestionTypeFromString(questionTypeString);

                            if (questionType.HasValue)
                            {
                                question.QuestionType = questionType.Value;
                            }

                            if (reader["Image"] != DBNull.Value)
                            {
                                byte[] imageBytes = (byte[])reader["Image"];
                                question.Image = ByteArrayToImage(imageBytes);
                            }

                            questions.Add(question);
                        }
                    }

                    reader.Close();

                    foreach (var question in questions)
                    {
                        string queryAnswers = "SELECT * FROM Answers WHERE QuestionID = @QuestionID";
                        SqlCommand answerCommand = new SqlCommand(queryAnswers, db.GetConnection());
                        answerCommand.Parameters.AddWithValue("@QuestionID", question.QuestionID);

                        SqlDataReader answerReader = answerCommand.ExecuteReader();

                        while (answerReader.Read())
                        {
                            Answer answer = new Answer
                            {
                                AnswerID = (int)answerReader["AnswerID"],
                                QuestionID = (int)answerReader["QuestionID"],
                                AnswerText = answerReader["AnswerText"].ToString(),
                                IsCorrect = (bool)answerReader["IsCorrect"]
                            };
                            question.Answers.Add(answer);
                        }
                        answerReader.Close();
                    }

                    db.CloseConnection();

                    if (questions.Count > 0)
                    {
                        currentQuestionIndex = 0;
                        DisplayCurrentQuestion();
                    }
                    else
                    {
                        MessageBox.Show("Нет доступных вопросов для данного теста.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при загрузке вопросов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private Image ByteArrayToImage(byte[] byteArrayIn)
        {
            using (MemoryStream ms = new MemoryStream(byteArrayIn))
            {
                return Image.FromStream(ms);
            }
        }

        private void DisplayCurrentQuestion()
        {
            if (currentQuestionIndex >= 0 && currentQuestionIndex < questions.Count)
            {
                Question currentQuestion = questions[currentQuestionIndex];
                Quest.Controls.Clear();
                Quest.Text = currentQuestion.QuestionText;

                Quest.Controls.Clear();
                int currentY = 10;

                TextBox textBox = new TextBox
                {
                    Text = currentQuestion.QuestionText,
                    AutoSize = true,
                    Location = new Point(10, currentY),
                    Height = 20,
                    Width = 600,
                    ReadOnly = true
                };
                TextBox questionCounter = new TextBox
                {
                    Text = $"Вопрос {currentQuestionIndex + 1} из {questions.Count}",
                    AutoSize = true,
                    Location = new Point(650, 10),
                    Height = 20,
                    Width = 100,
                    ReadOnly = true
                };
                Quest.Controls.Add(questionCounter);
                Quest.Controls.Add(textBox);
                currentY += textBox.Height + 10;

                if (currentQuestion.Image != null)
                {
                    PictureBox pictureBox = new PictureBox
                    {
                        Image = currentQuestion.Image,
                        SizeMode = PictureBoxSizeMode.StretchImage,
                        Location = new Point(10, currentY),
                        Size = new Size(296, 189)
                    };
                    Quest.Controls.Add(pictureBox);
                    currentY += pictureBox.Height + 10;
                }

                switch (currentQuestion.QuestionType)
                {
                    case QuestionType.SingleChoice:
                        foreach (var answer in currentQuestion.Answers)
                        {
                            TextBox textbox = new TextBox
                            {
                                Text = answer.AnswerText,
                                AutoSize = true,
                                Location = new Point(10, currentY),
                                Height = 20,
                                Width = 600,
                                ReadOnly = true
                            };

                            RadioButton radioButton = new RadioButton
                            {
                                Tag = answer,
                                Location = new Point(textbox.Right + 5, textbox.Top)
                            };

                            Quest.Controls.Add(textbox);
                            Quest.Controls.Add(radioButton);

                            currentY += textbox.Height + 10;
                        }
                        break;
                    case QuestionType.MultipleChoice:
                        foreach (var answer in currentQuestion.Answers)
                        {
                            TextBox textbox = new TextBox
                            {
                                Text = answer.AnswerText,
                                AutoSize = true,
                                Height = 20,
                                Width = 600,
                                ReadOnly = true,
                                Location = new Point(10, currentY)
                            };

                            CheckBox checkBox = new CheckBox
                            {
                                Tag = answer,
                                Location = new Point(textbox.Right + 5, textbox.Top)
                            };

                            Quest.Controls.Add(textbox);
                            Quest.Controls.Add(checkBox);

                            currentY += textbox.Height + 10;
                        }

                        break;
                    case QuestionType.Sequence:
                        foreach (var answer in currentQuestion.Answers)
                        {
                            Label label = new Label
                            {
                                Text = answer.AnswerText,
                                AutoSize = true,
                                Location = new Point(10, currentY)
                            };

                            TextBox textbox = new TextBox
                            {
                                Tag = answer,
                                Width = 100,
                                Location = new Point(label.Right + 5, label.Top)
                            };
                            Quest.Controls.Add(label);
                            Quest.Controls.Add(textBox);
                            currentY += label.Height + 10;
                        }
                        break;
                    default:
                        MessageBox.Show("Неизвестный тип вопроса.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                }
                this.Controls.Add(Quest);
                Quest.Controls.Add(CreateButton("Сохранить ответ", SaveAnswer, new System.Drawing.Point(10, 500)));
                Quest.Controls.Add(CreateButton("Следующий вопрос", NextQuestion, new System.Drawing.Point(300, 500)));
                Quest.Controls.Add(CreateButton("Предыдущий вопрос", PreviousQuestion, new System.Drawing.Point(150, 500)));
                if (currentQuestionIndex == questions.Count - 1)
                {
                    Quest.Controls.Add(CreateButton("Закончить тест", FinishButton, new System.Drawing.Point(650, 500)));
                }
            }
        }

        private Button CreateButton(string text, EventHandler handler, System.Drawing.Point location)
        {
            Button button = new Button
            {
                Text = text,
                Location = location,
                AutoSize = true
            };
            Quest.BringToFront();
            button.Click += handler;
            return button;
        }

        private void SaveAnswer(object sender, EventArgs e)
        {
            if (currentQuestionIndex < questions.Count)
            {
                var currentQuestion = questions[currentQuestionIndex];
                bool isCorrect = false;

                switch (currentQuestion.QuestionType)
                {
                    case QuestionType.SingleChoice:
                        foreach (RadioButton radioButton in Quest.Controls.OfType<RadioButton>())
                        {
                            if (radioButton.Checked)
                            {
                                var selectedAnswer = (Answer)radioButton.Tag;
                                isCorrect = selectedAnswer.IsCorrect;
                                break;
                            }
                        }
                        break;

                    case QuestionType.MultipleChoice:
                        isCorrect = true;
                        foreach (CheckBox checkBox in Quest.Controls.OfType<CheckBox>())
                        {
                            var answer = (Answer)checkBox.Tag;
                            if (checkBox.Checked && !answer.IsCorrect)
                            {
                                isCorrect = false;
                                break;
                            }
                            else if (!checkBox.Checked && answer.IsCorrect)
                            {
                                isCorrect = false;
                                break;
                            }
                        }
                        break;

                    case QuestionType.Sequence:
                        foreach (TextBox textBox in Quest.Controls.OfType<TextBox>())
                        {
                            var answer = (Answer)textBox.Tag;
                            if (textBox.Text.Equals(answer.AnswerText, StringComparison.OrdinalIgnoreCase))
                            {
                                isCorrect = true;
                            }
                            else
                            {
                                isCorrect = false;
                                break;
                            }
                        }
                        break;
                }

                if (isCorrect)
                {
                    score++;
                }
                currentQuestionIndex++;
                Quest.BringToFront();
                if (currentQuestionIndex < questions.Count)
                {
                    DisplayCurrentQuestion();
                }
                else
                {
                    MessageBox.Show("Вы ответили на все вопросы.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void FinishButton(object sender, EventArgs e)
        {
            MessageBox.Show($"Тест завершен! Вы набрали {score} из {totalQuestions} баллов.", "Результаты", MessageBoxButtons.OK, MessageBoxIcon.Information);

            SaveTestResults(score, _testId);

            this.Close();
            Quest.BringToFront();

        }

        private void SaveTestResults(int score, int testId)
        {
            using (DB db = new DB())
            {
                SqlCommand command = null;
                try
                {
                    db.OpenConnection();

                    string query = "INSERT INTO TestResults (UserID, TestID, ResultTest) VALUES (@UserID, @TestID, @ResultTest)";
                    command = new SqlCommand(query, db.GetConnection());

                    command.Parameters.AddWithValue("@UserID", this.userId);
                    command.Parameters.AddWithValue("@TestID", testId);
                    command.Parameters.AddWithValue("@ResultTest", score);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {

                    }
                    else
                    {
                        MessageBox.Show("Не удалось сохранить результаты.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show($"Ошибка базы данных: {sqlEx.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении результатов: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    if (command != null)
                    {
                        command.Dispose();
                    }
                    db.CloseConnection();
                }
            }
        }

        private void NextQuestion(object sender, EventArgs e)
        {
            if (currentQuestionIndex < questions.Count - 1)
            {
                currentQuestionIndex++;
                DisplayCurrentQuestion();
                Quest.BringToFront();
            }
            else
            {
                MessageBox.Show("Это последний вопрос.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void PreviousQuestion(object sender, EventArgs e)
        {
            if (currentQuestionIndex > 0)
            {
                currentQuestionIndex--;
                DisplayCurrentQuestion();
                Quest.BringToFront();
            }
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Вы точно хотите закончить прохождение теста?", "Предупреждение", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (result == DialogResult.Yes)
            {
                this.Hide();
                userForm userForm = new userForm(userId);
                userForm.Show();
            }
        }
    }
}