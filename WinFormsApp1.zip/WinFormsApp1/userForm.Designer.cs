﻿namespace WinFormsApp1
{
    partial class userForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userForm));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            panel1 = new Panel();
            ReturnButton = new Button();
            Test = new DataGridView();
            IDTest = new DataGridViewTextBoxColumn();
            NameTest = new DataGridViewTextBoxColumn();
            ThemeTest = new DataGridViewTextBoxColumn();
            SumTest = new DataGridViewTextBoxColumn();
            StartTest = new DataGridViewButtonColumn();
            MyToolTip = new ToolTip(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Test).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            resources.ApplyResources(panel1, "panel1");
            panel1.BackColor = SystemColors.ActiveBorder;
            panel1.Controls.Add(ReturnButton);
            panel1.Name = "panel1";
            MyToolTip.SetToolTip(panel1, resources.GetString("panel1.ToolTip"));
            // 
            // ReturnButton
            // 
            resources.ApplyResources(ReturnButton, "ReturnButton");
            ReturnButton.FlatAppearance.BorderSize = 0;
            ReturnButton.Name = "ReturnButton";
            MyToolTip.SetToolTip(ReturnButton, resources.GetString("ReturnButton.ToolTip"));
            ReturnButton.UseVisualStyleBackColor = true;
            ReturnButton.Click += ReturnButton_Click;
            // 
            // Test
            // 
            resources.ApplyResources(Test, "Test");
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle1.BackColor = SystemColors.Control;
            dataGridViewCellStyle1.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = SystemColors.ControlLight;
            dataGridViewCellStyle1.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = DataGridViewTriState.True;
            Test.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            Test.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Test.Columns.AddRange(new DataGridViewColumn[] { IDTest, NameTest, ThemeTest, SumTest, StartTest });
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle2.BackColor = SystemColors.Window;
            dataGridViewCellStyle2.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle2.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = SystemColors.ControlLight;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.ControlText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.False;
            Test.DefaultCellStyle = dataGridViewCellStyle2;
            Test.Name = "Test";
            MyToolTip.SetToolTip(Test, resources.GetString("Test.ToolTip"));
            Test.CellContentClick += Test_CellContentClick;
            // 
            // IDTest
            // 
            resources.ApplyResources(IDTest, "IDTest");
            IDTest.Name = "IDTest";
            // 
            // NameTest
            // 
            resources.ApplyResources(NameTest, "NameTest");
            NameTest.Name = "NameTest";
            NameTest.ReadOnly = true;
            // 
            // ThemeTest
            // 
            resources.ApplyResources(ThemeTest, "ThemeTest");
            ThemeTest.Name = "ThemeTest";
            ThemeTest.ReadOnly = true;
            // 
            // SumTest
            // 
            resources.ApplyResources(SumTest, "SumTest");
            SumTest.Name = "SumTest";
            SumTest.ReadOnly = true;
            // 
            // StartTest
            // 
            resources.ApplyResources(StartTest, "StartTest");
            StartTest.Name = "StartTest";
            StartTest.Text = "Пройти тест";
            StartTest.UseColumnTextForButtonValue = true;
            // 
            // MyToolTip
            // 
            MyToolTip.AutoPopDelay = 5000;
            MyToolTip.InitialDelay = 100;
            MyToolTip.ReshowDelay = 100;
            // 
            // userForm
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Test);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "userForm";
            MyToolTip.SetToolTip(this, resources.GetString("$this.ToolTip"));
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)Test).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button ReturnButton;
        private DataGridView Test;
        private ToolTip MyToolTip;
        private Button ChgAdmin;
        private DataGridViewTextBoxColumn IDTest;
        private DataGridViewTextBoxColumn NameTest;
        private DataGridViewTextBoxColumn ThemeTest;
        private DataGridViewTextBoxColumn SumTest;
        private DataGridViewButtonColumn StartTest;
    }
}