﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.DirectoryServices.ActiveDirectory;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic.ApplicationServices;
using MongoDB.Driver.Core.Configuration;
using Org.BouncyCastle.Asn1;
using static System.Net.Mime.MediaTypeNames;

namespace WinFormsApp1
{
    public partial class AdminForm : Form
    {
        public AdminForm()
        {
            InitializeComponent();
            LoadData();

            Test.CellContentClick += Test1_CellContentClick;
        }

        [Obsolete]
        private void LoadData()
        {
            using (DB db = new DB())
            {
                try
                {
                    db.OpenConnection();

                    string queryTests = "SELECT * FROM Tests ORDER BY TestID";

                    SqlCommand command = new SqlCommand(queryTests, db.GetConnection());

                    SqlDataReader reader = command.ExecuteReader();

                    List<string[]> data = new List<string[]>();

                    while (reader.Read())
                    {
                        data.Add(new string[4]);

                        data[data.Count - 1][0] = reader[0].ToString();
                        data[data.Count - 1][1] = reader[1].ToString();
                        data[data.Count - 1][2] = reader[2].ToString();
                        data[data.Count - 1][3] = reader[3].ToString();

                    }

                    reader.Close();

                    db.CloseConnection();

                    Test.Rows.Clear();

                    foreach (string[] s in data)
                        Test.Rows.Add(s);
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void CreateTest_Click(object sender, EventArgs e)
        {
            this.Show();
            int testId = 1;
            TestCreate TestCreate = new TestCreate(this);
            TestCreate.Show();
        }

        [Obsolete]
        private void Test_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == Test.Columns["DeleteTest"].Index && e.RowIndex >= 0)
            {
                try
                {
                    int testId = Convert.ToInt32(Test.Rows[e.RowIndex].Cells["IDTest"].Value);


                    var result = MessageBox.Show("Вы уверены, что хотите удалить этот тест?", "Удаление", MessageBoxButtons.YesNo);
                    if (result == DialogResult.Yes)
                    {
                        DeleteTest1(testId);
                    }
                }
                catch (FormatException)
                {
                    MessageBox.Show("Ошибка: Неверный формат ID теста.", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        [Obsolete]
        private void DeleteTest1(int testId)
        {
            using (DB db = new DB())
            {
                try
                {
                    db.OpenConnection();

                    string deleteAnswersQuery = "DELETE FROM Answers WHERE QuestionID IN (SELECT QuestionID FROM Questions WHERE TestID = @TestId)";
                    using (SqlCommand deleteAnswersCommand = new SqlCommand(deleteAnswersQuery, db.GetConnection()))
                    {
                        deleteAnswersCommand.Parameters.AddWithValue("@TestId", testId);
                        deleteAnswersCommand.ExecuteNonQuery();
                    }

                    string deleteQuestionsQuery = "DELETE FROM Questions WHERE TestID = @TestId";
                    using (SqlCommand deleteQuestionsCommand = new SqlCommand(deleteQuestionsQuery, db.GetConnection()))
                    {
                        deleteQuestionsCommand.Parameters.AddWithValue("@TestId", testId);
                        deleteQuestionsCommand.ExecuteNonQuery();
                    }

                    string deleteTestQuery = "DELETE FROM Tests WHERE TestID = @TestId";
                    using (SqlCommand deleteTestCommand = new SqlCommand(deleteTestQuery, db.GetConnection()))
                    {
                        deleteTestCommand.Parameters.AddWithValue("@TestId", testId);
                        int rowsAffected = deleteTestCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Тест и связанные данные успешно удалены.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            RefreshTestTable();
                        }
                        else
                        {
                            MessageBox.Show("Тест не найден или уже удален.", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
                catch (SqlException sqlEx)
                {
                    MessageBox.Show($"Ошибка базы данных: {sqlEx.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        [Obsolete]
        public void RefreshTestTable()
        {
            LoadData();
        }

        private void Test1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == Test.Columns["EditTest"].Index && e.RowIndex >= 0)
            {
                var idTestCellValue = Test.Rows[e.RowIndex].Cells["IDTest"].Value;

                if (idTestCellValue == null)
                {
                    MessageBox.Show("ID теста не найден.");
                    return;
                }

                string idTestString = idTestCellValue.ToString();
                int idTest;

                if (int.TryParse(idTestString, out idTest))
                {
                    AdminForm adminForm = this;
                    EditForm editForm = new EditForm(adminForm, idTest);
                    editForm.Show();
                }
                else
                {
                    MessageBox.Show("Некорректный ID теста: " + idTestString);
                }
            }
        }

        private void ReturnButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Test Test = new Test();
            Test.Show();
        }
    }
}
