﻿namespace WinFormsApp1
{
    partial class RunTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RunTest));
            Info = new Panel();
            ReturnButton = new Button();
            toolTip1 = new ToolTip(components);
            Tests = new Panel();
            Info.SuspendLayout();
            SuspendLayout();
            // 
            // Info
            // 
            resources.ApplyResources(Info, "Info");
            Info.BackColor = SystemColors.ActiveBorder;
            Info.Controls.Add(ReturnButton);
            Info.Name = "Info";
            toolTip1.SetToolTip(Info, resources.GetString("Info.ToolTip"));
            // 
            // ReturnButton
            // 
            resources.ApplyResources(ReturnButton, "ReturnButton");
            ReturnButton.FlatAppearance.BorderSize = 0;
            ReturnButton.Name = "ReturnButton";
            toolTip1.SetToolTip(ReturnButton, resources.GetString("ReturnButton.ToolTip"));
            ReturnButton.UseVisualStyleBackColor = true;
            // 
            // toolTip1
            // 
            toolTip1.AutoPopDelay = 5000;
            toolTip1.InitialDelay = 100;
            toolTip1.ReshowDelay = 100;
            // 
            // Tests
            // 
            resources.ApplyResources(Tests, "Tests");
            Tests.Name = "Tests";
            toolTip1.SetToolTip(Tests, resources.GetString("Tests.ToolTip"));
            // 
            // RunTest
            // 
            resources.ApplyResources(this, "$this");
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(Tests);
            Controls.Add(Info);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            Name = "RunTest";
            toolTip1.SetToolTip(this, resources.GetString("$this.ToolTip"));
            Info.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel Info;
        private Button ReturnButton;
        private Label label1;
        private TextBox textBox1;
        private Label label3;
        private TextBox textBox3;
        private Label label2;
        private TextBox textBox2;
        private Panel Test;
        private ToolTip toolTip1;
        private Button saveButton;
        private Button nextButton;
        private Button previousButton;
        private Button finishButton;
        private Panel Tests;
        private TextBox textBox4;
        private Button button1;
    }
}