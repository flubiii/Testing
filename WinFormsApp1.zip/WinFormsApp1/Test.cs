using System.Data;
using System.Data.SqlClient;
using Microsoft.VisualBasic.ApplicationServices;

namespace WinFormsApp1
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();

            LoginText.Text = "������� �����";
            LoginText.ForeColor = Color.Silver;

            PasswordText.Text = "������� ������";
            PasswordText.ForeColor = Color.Silver;
        }

        [Obsolete]
        private void button1_Click_1(object sender, EventArgs e)
        {
            string loginUser = LoginText.Text;
            string passUser = PasswordText.Text;

            DB db = new DB();
            DataTable table = new DataTable();

            SqlDataAdapter adapter = new SqlDataAdapter();

            SqlCommand command = new SqlCommand("SELECT Id, Role FROM Users WHERE Username = @uL AND Password = @uP", db.GetConnection());

            command.Parameters.Add("@uL", SqlDbType.VarChar).Value = loginUser;
            command.Parameters.Add("@uP", SqlDbType.VarChar).Value = passUser;

            adapter.SelectCommand = command;

            try
            {
                db.OpenConnection();
                adapter.Fill(table);

                if (table.Rows.Count > 0)
                {
                    int userId = Convert.ToInt32(table.Rows[0]["Id"]);
                    string userRole = table.Rows[0]["Role"].ToString();

                    this.Hide();

                    if (userRole == "Admin")
                    {
                        AdminForm adminForm = new AdminForm();
                        adminForm.Show();
                    }
                    else if (userRole == "User")
                    {
                        userForm userForm = new userForm(userId);
                        userForm.Show();
                    }
                    else
                    {
                        MessageBox.Show("����������� ���� ������������.");
                    }
                }
                else
                {
                    MessageBox.Show("�� �� ��������������!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("������: " + ex.Message);
            }
            finally
            {
                db.CloseConnection();
            }
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            this.Hide();
            Register register = new Register();
            register.Show();
        }

        private void LoginText_Enter(object sender, EventArgs e)
        {
            if (LoginText.Text == "������� �����")
            {
                LoginText.Text = "";
                LoginText.ForeColor = Color.Black;
            }
        }

        private void LoginText_Leave(object sender, EventArgs e)
        {
            if (LoginText.Text == "")
            {
                LoginText.Text = "������� �����";
                LoginText.ForeColor = Color.Silver;
            }
        }

        private void PasswordText_Enter(object sender, EventArgs e)
        {
            if (PasswordText.Text == "������� ������")
            {
                PasswordText.Text = "";
                PasswordText.ForeColor = Color.Black;
            }
        }

        private void PasswordText_Leave(object sender, EventArgs e)
        {
            if (PasswordText.Text == "")
            {
                PasswordText.Text = "������� ������";
                PasswordText.ForeColor = Color.Silver;
            }
        }
    }
}
