﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class TestCreate : Form
    {
        private AdminForm _adminForm;
        public TestCreate(AdminForm adminForm)
        {
            InitializeComponent();
            _adminForm = adminForm;

            SetPlaceholder(NameTest, "Введите название теста");
            SetPlaceholder(ThemeTest, "Введите тему теста");
        }

        private void SetPlaceholder(TextBox textBox, string placeholder)
        {
            textBox.Text = placeholder;
            textBox.ForeColor = Color.Silver;
            textBox.GotFocus += (s, e) => RemovePlaceholder(textBox, placeholder);
            textBox.LostFocus += (s, e) => SetPlaceholderIfEmpty(textBox, placeholder);
        }

        private void RemovePlaceholder(TextBox textBox, string placeholder)
        {
            if (textBox.Text == placeholder)
            {
                textBox.Text = "";
                textBox.ForeColor = Color.Black;
            }
        }

        private void SetPlaceholderIfEmpty(TextBox textBox, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.ForeColor = Color.Silver;
            }
        }

        [Obsolete]
        private void SaveTest_Click(object sender, EventArgs e)
        {
            string nameTest = NameTest.Text.Trim();
            string themeTest = ThemeTest.Text.Trim();

            if (nameTest == "Введите название теста" || string.IsNullOrWhiteSpace(nameTest))
            {
                MessageBox.Show("Название теста обязательно для заполнения.");
                return;
            }

            if (themeTest == "Введите тему для теста" || string.IsNullOrWhiteSpace(themeTest))
            {
                MessageBox.Show("Тема теста обязательна для заполнения.");
                return;
            }

            using (DB db = new DB())
            {
                db.OpenConnection();

                using (SqlCommand command = new SqlCommand("INSERT INTO Tests (TestName, Subject) VALUES (@nm, @sb);", db.GetConnection()))
                {
                    command.Parameters.Add("@nm", SqlDbType.NVarChar).Value = nameTest;
                    command.Parameters.Add("@sb", SqlDbType.NVarChar).Value = themeTest;
                    try
                    {
                        if (command.ExecuteNonQuery() == 1)
                        {
                            MessageBox.Show("Тест создан");
                            this.Hide();
                            AdminCreateForm AdminCreateForm = new AdminCreateForm(_adminForm);
                            AdminCreateForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("Тест не создан");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
        }
    }
}
