﻿namespace WinFormsApp1
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            DataGridViewCellStyle dataGridViewCellStyle13 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle14 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle15 = new DataGridViewCellStyle();
            panel1 = new Panel();
            label1 = new Label();
            ReturnButton = new Button();
            CreateTest = new Button();
            toolTip1 = new ToolTip(components);
            Test = new DataGridView();
            IDTest = new DataGridViewTextBoxColumn();
            NameTest = new DataGridViewTextBoxColumn();
            ThemeTest = new DataGridViewTextBoxColumn();
            SumTest = new DataGridViewTextBoxColumn();
            EditTest = new DataGridViewButtonColumn();
            DeleteTest = new DataGridViewButtonColumn();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)Test).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ActiveBorder;
            panel1.Controls.Add(label1);
            panel1.Controls.Add(ReturnButton);
            panel1.Controls.Add(CreateTest);
            panel1.Location = new Point(-31, -21);
            panel1.Name = "panel1";
            panel1.Size = new Size(1143, 96);
            panel1.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            label1.Location = new Point(430, 43);
            label1.Name = "label1";
            label1.Size = new Size(278, 30);
            label1.TabIndex = 12;
            label1.Text = "Панель администратора";
            // 
            // ReturnButton
            // 
            ReturnButton.FlatAppearance.BorderSize = 0;
            ReturnButton.FlatStyle = FlatStyle.Flat;
            ReturnButton.Image = (Image)resources.GetObject("ReturnButton.Image");
            ReturnButton.ImeMode = ImeMode.NoControl;
            ReturnButton.Location = new Point(43, 33);
            ReturnButton.Name = "ReturnButton";
            ReturnButton.Size = new Size(45, 43);
            ReturnButton.TabIndex = 11;
            toolTip1.SetToolTip(ReturnButton, "Вернуться на главную");
            ReturnButton.UseVisualStyleBackColor = true;
            ReturnButton.Click += ReturnButton1_Click;
            // 
            // CreateTest
            // 
            CreateTest.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            CreateTest.FlatAppearance.BorderSize = 0;
            CreateTest.FlatStyle = FlatStyle.Flat;
            CreateTest.Image = (Image)resources.GetObject("CreateTest.Image");
            CreateTest.Location = new Point(1013, 33);
            CreateTest.Name = "CreateTest";
            CreateTest.Size = new Size(45, 43);
            CreateTest.TabIndex = 8;
            toolTip1.SetToolTip(CreateTest, "Создать тест");
            CreateTest.UseVisualStyleBackColor = true;
            CreateTest.Click += CreateTest_Click;
            // 
            // Test
            // 
            dataGridViewCellStyle13.Alignment = DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle13.BackColor = SystemColors.Control;
            dataGridViewCellStyle13.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle13.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = SystemColors.ControlLight;
            dataGridViewCellStyle13.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = DataGridViewTriState.True;
            Test.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            Test.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            Test.Columns.AddRange(new DataGridViewColumn[] { IDTest, NameTest, ThemeTest, SumTest, EditTest, DeleteTest });
            dataGridViewCellStyle14.Alignment = DataGridViewContentAlignment.TopLeft;
            dataGridViewCellStyle14.BackColor = SystemColors.Window;
            dataGridViewCellStyle14.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 204);
            dataGridViewCellStyle14.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = SystemColors.ControlLight;
            dataGridViewCellStyle14.SelectionForeColor = SystemColors.ControlText;
            dataGridViewCellStyle14.WrapMode = DataGridViewTriState.False;
            Test.DefaultCellStyle = dataGridViewCellStyle14;
            Test.Location = new Point(2, 81);
            Test.Name = "Test";
            dataGridViewCellStyle15.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = SystemColors.Control;
            dataGridViewCellStyle15.Font = new Font("Segoe UI", 9F);
            dataGridViewCellStyle15.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = DataGridViewTriState.True;
            Test.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            Test.Size = new Size(1055, 585);
            Test.TabIndex = 10;
            Test.CellContentClick += Test_CellContentClick;
            // 
            // IDTest
            // 
            IDTest.HeaderText = "ID";
            IDTest.Name = "IDTest";
            IDTest.Visible = false;
            // 
            // NameTest
            // 
            NameTest.HeaderText = "Название теста";
            NameTest.Name = "NameTest";
            NameTest.ReadOnly = true;
            NameTest.Width = 400;
            // 
            // ThemeTest
            // 
            ThemeTest.HeaderText = "Тема теста";
            ThemeTest.Name = "ThemeTest";
            ThemeTest.ReadOnly = true;
            ThemeTest.Width = 230;
            // 
            // SumTest
            // 
            SumTest.HeaderText = "Количество вопросов";
            SumTest.Name = "SumTest";
            SumTest.ReadOnly = true;
            SumTest.Width = 180;
            // 
            // EditTest
            // 
            EditTest.HeaderText = "";
            EditTest.Name = "EditTest";
            EditTest.Text = "Редактировать";
            EditTest.ToolTipText = "Редактировать тест";
            EditTest.UseColumnTextForButtonValue = true;
            // 
            // DeleteTest
            // 
            DeleteTest.HeaderText = "";
            DeleteTest.Name = "DeleteTest";
            DeleteTest.Text = "Удалить";
            DeleteTest.ToolTipText = "Удалить тест";
            DeleteTest.UseColumnTextForButtonValue = true;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1052, 664);
            Controls.Add(Test);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "AdminForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Тестирование";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)Test).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button CreateTest;
        private ToolTip toolTip1;
        private DataGridView Test;
        private DataGridViewTextBoxColumn IDTest;
        private DataGridViewTextBoxColumn NameTest;
        private DataGridViewTextBoxColumn ThemeTest;
        private DataGridViewTextBoxColumn SumTest;
        private DataGridViewButtonColumn EditTest;
        private DataGridViewButtonColumn DeleteTest;
        private Button ReturnButton;
        private Button ReturnButton1;
        private Label label1;
    }
}