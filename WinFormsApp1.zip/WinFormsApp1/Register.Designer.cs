﻿namespace WinFormsApp1
{
    partial class Register
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Register));
            panel1 = new Panel();
            LastNameRegText = new TextBox();
            FirstNameRegText = new TextBox();
            ReturnIcon = new Button();
            PasswordIcon = new PictureBox();
            LoginIcon = new PictureBox();
            PasswordRegText = new TextBox();
            LoginRegText = new TextBox();
            buttonReg = new Button();
            Logo = new PictureBox();
            BackImage = new PictureBox();
            Help = new ToolTip(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PasswordIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)LoginIcon).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Logo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BackImage).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(LastNameRegText);
            panel1.Controls.Add(FirstNameRegText);
            panel1.Controls.Add(ReturnIcon);
            panel1.Controls.Add(PasswordIcon);
            panel1.Controls.Add(LoginIcon);
            panel1.Controls.Add(PasswordRegText);
            panel1.Controls.Add(LoginRegText);
            panel1.Controls.Add(buttonReg);
            panel1.Controls.Add(Logo);
            panel1.Location = new Point(158, -22);
            panel1.Name = "panel1";
            panel1.Size = new Size(337, 670);
            panel1.TabIndex = 5;
            // 
            // LastNameRegText
            // 
            LastNameRegText.Location = new Point(56, 378);
            LastNameRegText.Name = "LastNameRegText";
            LastNameRegText.Size = new Size(230, 23);
            LastNameRegText.TabIndex = 11;
            // 
            // FirstNameRegText
            // 
            FirstNameRegText.Location = new Point(56, 328);
            FirstNameRegText.Name = "FirstNameRegText";
            FirstNameRegText.Size = new Size(230, 23);
            FirstNameRegText.TabIndex = 10;
            // 
            // ReturnIcon
            // 
            ReturnIcon.AutoSize = true;
            ReturnIcon.BackColor = Color.Transparent;
            ReturnIcon.FlatAppearance.BorderColor = Color.Silver;
            ReturnIcon.FlatAppearance.BorderSize = 0;
            ReturnIcon.FlatStyle = FlatStyle.Flat;
            ReturnIcon.Image = (Image)resources.GetObject("ReturnIcon.Image");
            ReturnIcon.Location = new Point(140, 557);
            ReturnIcon.Name = "ReturnIcon";
            ReturnIcon.Size = new Size(58, 58);
            ReturnIcon.TabIndex = 9;
            ReturnIcon.UseVisualStyleBackColor = false;
            ReturnIcon.Click += ReturnIcon_Click;
            // 
            // PasswordIcon
            // 
            PasswordIcon.Image = (Image)resources.GetObject("PasswordIcon.Image");
            PasswordIcon.ImeMode = ImeMode.NoControl;
            PasswordIcon.Location = new Point(23, 427);
            PasswordIcon.Name = "PasswordIcon";
            PasswordIcon.Size = new Size(27, 23);
            PasswordIcon.SizeMode = PictureBoxSizeMode.StretchImage;
            PasswordIcon.TabIndex = 8;
            PasswordIcon.TabStop = false;
            // 
            // LoginIcon
            // 
            LoginIcon.Image = (Image)resources.GetObject("LoginIcon.Image");
            LoginIcon.ImeMode = ImeMode.NoControl;
            LoginIcon.Location = new Point(23, 279);
            LoginIcon.Name = "LoginIcon";
            LoginIcon.Size = new Size(27, 23);
            LoginIcon.SizeMode = PictureBoxSizeMode.StretchImage;
            LoginIcon.TabIndex = 7;
            LoginIcon.TabStop = false;
            // 
            // PasswordRegText
            // 
            PasswordRegText.Location = new Point(56, 427);
            PasswordRegText.Name = "PasswordRegText";
            PasswordRegText.PasswordChar = '*';
            PasswordRegText.Size = new Size(230, 23);
            PasswordRegText.TabIndex = 4;
            Help.SetToolTip(PasswordRegText, "Пароль должен содержать не менее 8 символов, включая заглавные и строчные буквы, цифры и специальные символы");
            PasswordRegText.UseSystemPasswordChar = true;
            // 
            // LoginRegText
            // 
            LoginRegText.Location = new Point(56, 279);
            LoginRegText.Name = "LoginRegText";
            LoginRegText.Size = new Size(230, 23);
            LoginRegText.TabIndex = 3;
            Help.SetToolTip(LoginRegText, "Логин должен содержать только буквы и цифры и не может быть пустым");
            // 
            // buttonReg
            // 
            buttonReg.BackColor = Color.CornflowerBlue;
            buttonReg.FlatAppearance.BorderColor = Color.Silver;
            buttonReg.FlatAppearance.BorderSize = 0;
            buttonReg.FlatStyle = FlatStyle.Flat;
            buttonReg.Font = new Font("Arial", 12F, FontStyle.Bold);
            buttonReg.ImeMode = ImeMode.NoControl;
            buttonReg.Location = new Point(56, 490);
            buttonReg.Name = "buttonReg";
            buttonReg.Size = new Size(230, 46);
            buttonReg.TabIndex = 2;
            buttonReg.Text = "Зарегестрироваться";
            buttonReg.UseVisualStyleBackColor = false;
            buttonReg.Click += buttonR_Click;
            // 
            // Logo
            // 
            Logo.Image = (Image)resources.GetObject("Logo.Image");
            Logo.ImeMode = ImeMode.NoControl;
            Logo.Location = new Point(5, 115);
            Logo.Name = "Logo";
            Logo.Size = new Size(326, 82);
            Logo.TabIndex = 0;
            Logo.TabStop = false;
            // 
            // BackImage
            // 
            BackImage.Image = (Image)resources.GetObject("BackImage.Image");
            BackImage.ImeMode = ImeMode.NoControl;
            BackImage.Location = new Point(-6, -3);
            BackImage.Name = "BackImage";
            BackImage.Size = new Size(1737, 944);
            BackImage.TabIndex = 4;
            BackImage.TabStop = false;
            // 
            // Help
            // 
            Help.AutoPopDelay = 5000;
            Help.InitialDelay = 100;
            Help.IsBalloon = true;
            Help.ReshowDelay = 100;
            Help.ShowAlways = true;
            // 
            // Register
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1013, 631);
            Controls.Add(panel1);
            Controls.Add(BackImage);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "Register";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Тестирование";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)PasswordIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)LoginIcon).EndInit();
            ((System.ComponentModel.ISupportInitialize)Logo).EndInit();
            ((System.ComponentModel.ISupportInitialize)BackImage).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private TextBox PasswordRegText;
        private TextBox LoginRegText;
        private Button buttonReg;
        private PictureBox Logo;
        private PictureBox BackImage;
        private PictureBox LoginIcon;
        private PictureBox PasswordIcon;
        private Button ReturnIcon;
        private ToolTip Help;
        private TextBox FirstNameRegText;
        private TextBox LastNameRegText;
    }
}