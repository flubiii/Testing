﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Org.BouncyCastle.Crypto;
using static WinFormsApp1.RunTest;

namespace WinFormsApp1
{
    public partial class EditForm : Form
    {
        private AdminForm _adminForm;
        private int _idTest;
        private int selectedQuestionId;

        private List<AnswerOption> answerOptions = new List<AnswerOption>();
        private string currentQuestionText;
        private string currentQuestionType;

        [Obsolete]
        public EditForm(AdminForm adminForm, int idTest)
        {
            InitializeComponent();

            _adminForm = adminForm;
            _idTest = idTest;
            LoadQuestions();
            Questions.SelectedIndexChanged += Questions_SelectedIndexChanged;

            this.QuestionTest.Items.AddRange(new string[] { "Один ответ", "Несколько ответов", "Последовательность ответов" });
            this.QuestionTest.SelectedIndexChanged += ComboBoxQuestionTypes_SelectedIndexChanged;
            this.Questions.SelectedIndexChanged += Questions_SelectedIndexChanged;
        }


        [Obsolete]
        private void LoadQuestions()
        {
            using (DB db = new DB())
            {
                db.OpenConnection();
                string query = "SELECT QuestionID, QuestionText FROM Questions WHERE TestID = @TestID";

                using (SqlCommand command = new SqlCommand(query, db.GetConnection()))
                {
                    command.Parameters.AddWithValue("@TestID", _idTest);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        Questions.Items.Clear();
                        while (reader.Read())
                        {
                            string questionText = reader["QuestionText"].ToString();
                            int questionId = Convert.ToInt32(reader["QuestionID"]);
                            Questions.Items.Add(new ComboBoxItem { Text = questionText, Value = questionId });
                        }
                    }
                }
            }
        }

        public class ComboBoxItem
        {
            public string Text { get; set; }
            public int Value { get; set; }

            public override string ToString() => Text;
        }

        public class AnswerOption
        {
            public int Id { get; set; }
            public string Text { get; set; }
            public bool IsCorrect { get; set; }
            public override string ToString() => Text;
        }


        [Obsolete]
        private void Questions_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Questions.SelectedItem != null)
            {

                var selectedItem = (ComboBoxItem)Questions.SelectedItem;

                currentQuestionText = selectedItem.Text;
                selectedQuestionId = selectedItem.Value;

                Console.WriteLine($"Выбранный ID вопроса: {selectedQuestionId}");
            }
        }

        private void ComboBoxQuestionTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddQuestion.Controls.Clear();
            if (Questions.SelectedItem is ComboBoxItem selectedItem)
            {
                int selectedQuestionId = selectedItem.Value;
                string selectedType = QuestionTest.SelectedItem?.ToString();
                LoadQuestionAndAnswers(selectedQuestionId, selectedType);
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите вопрос из списка.");
            }
        }


        private void LoadQuestionAndAnswers(int questionId, string questionType)
        {
            string questionText = string.Empty;
            using (DB db = new DB())
            {
                db.OpenConnection();
                string query = "SELECT QuestionText FROM Questions WHERE QuestionID = @QuestionID";
                using (SqlCommand command = new SqlCommand(query, db.GetConnection()))
                {
                    command.Parameters.AddWithValue("@QuestionID", questionId);
                    questionText = command.ExecuteScalar()?.ToString();
                }

                answerOptions.Clear(); 

                string answerQuery = "SELECT AnswerID, AnswerText, IsCorrect FROM Answers WHERE QuestionID = @QuestionID";
                using (SqlCommand command = new SqlCommand(answerQuery, db.GetConnection()))
                {
                    command.Parameters.AddWithValue("@QuestionID", questionId);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            answerOptions.Add(new AnswerOption
                            {
                                Id = Convert.ToInt32(reader["AnswerID"]),
                                Text = reader["AnswerText"].ToString(),
                                IsCorrect = Convert.ToBoolean(reader["IsCorrect"])
                            });
                        }
                    }
                }
            }

            Label questionLabel = new Label() { Text = "Введите вопрос:", AutoSize = true, Location = new Point(10, 20) };
            TextBox questionTextBox = new TextBox() { Width = 300, Location = new Point(10, 40), Text = questionText };
            AddQuestion.Controls.Add(questionLabel);
            AddQuestion.Controls.Add(questionTextBox);

            DisplayAnswerOptions(selectedQuestionId, questionType);
        }


        private void DisplayAnswerOptions(int questionId, string questionType)
        {
            for (int i = 0; i < answerOptions.Count; i++)
            {
                var option = answerOptions[i];

                string optionTextBoxName = $"optionTextBox{i}";

                Label optionLabel = new Label() { Text = $"Введите вариант ответа {i + 1}:", AutoSize = true, Location = new Point(10, 80 + i * 70) };
                TextBox optionTextBox = new TextBox() { Name = optionTextBoxName, Width = 300, Location = new Point(10, 100 + i * 70), Text = option.Text };

                AddQuestion.Controls.Add(optionLabel);
                AddQuestion.Controls.Add(optionTextBox);

                if (questionType == "Один ответ")
                {
                    RadioButton radioButton = new RadioButton() { Name = $"radioButton{i}", Text = $"Вариант {i + 1}", AutoSize = true, Location = new Point(325, 102 + i * 70) };
                    AddQuestion.Controls.Add(radioButton);
                    if (option.IsCorrect)
                    {
                        radioButton.Checked = true;
                    }
                }
                if (questionType == "Последовательность ответов")
                {

                }
                else if (questionType == "Несколько ответов")
                {
                    CheckBox checkBox = new CheckBox() { Name = $"checkBox{i}", Text = $"Вариант {i + 1}", AutoSize = true, Location = new Point(325, 102 + i * 70) };
                    AddQuestion.Controls.Add(checkBox);
                    checkBox.Checked = option.IsCorrect;
                }
            }

            if (questionType == "Последовательность ответов")
            {
                Label sequenceLabel = new Label() { Text = "Введите последовательность (через запятую):", AutoSize = true, Location = new Point(10, 80 + answerOptions.Count * 70) };
                TextBox sequenceTextBox = new TextBox() { Width = 300, Location = new Point(10, 100 + answerOptions.Count * 70) };
                AddQuestion.Controls.Add(sequenceLabel);
                AddQuestion.Controls.Add(sequenceTextBox);
            }
        }

        [Obsolete]
        private void SaveQuestion_Click(object sender, EventArgs e)
        {
            var questionTextBox = AddQuestion.Controls.OfType<TextBox>().FirstOrDefault();
            if (questionTextBox != null && string.IsNullOrEmpty(questionTextBox.Text))
            {
                MessageBox.Show("Вопрос не может быть пустым.");
                return;
            }

            string updatedText = questionTextBox.Text;
            string selectedType = QuestionTest.SelectedItem?.ToString();
            UpdateQuestionInDb(selectedQuestionId, updatedText, selectedType);

            SaveAnswersToDb(selectedQuestionId, selectedType); 
        }

        private void UpdateQuestionInDb(int questionId, string newText, string newType)
        {
            try
            {
                using (DB db = new DB())
                {
                    db.OpenConnection();
                    string query = "UPDATE Questions SET QuestionText = @QuestionText, QuestionType = @QuestionType WHERE QuestionID = @QuestionID";

                    using (SqlCommand command = new SqlCommand(query, db.GetConnection()))
                    {
                        command.Parameters.AddWithValue("@QuestionText", newText);
                        command.Parameters.AddWithValue("@QuestionType", newType); 
                        command.Parameters.AddWithValue("@QuestionID", questionId);

                        int result = command.ExecuteNonQuery();
                        if (result > 0)
                            MessageBox.Show("Вопрос успешно обновлён!");
                        else
                            MessageBox.Show("Ошибка обновления вопроса. Проверьте данные.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}");
            }
        }

        private void SaveAnswersToDb(int questionId, string questionType)
        {
            using (DB db = new DB())
            {
                db.OpenConnection();
                try
                {
                    DeleteOldAnswersFromDb(db, questionId);
                    if (questionType == "Один ответ" || questionType == "Несколько ответов")
                    {
                        foreach (Control control in AddQuestion.Controls)
                        {
                            if (control is RadioButton radioButton)
                            {
                                int index = GetControlIndex(radioButton.Name, "radioButton");
                                if (index != -1)
                                {
                                    TextBox optionTextBox = AddQuestion.Controls.Find($"optionTextBox{index}", true).FirstOrDefault() as TextBox;
                                    if (optionTextBox != null)
                                    {
                                        bool isCorrect = radioButton.Checked; 
                                        SaveAnswerToDb(db, questionId, optionTextBox.Text, isCorrect);
                                    }
                                }
                            }
                            else if (control is CheckBox checkBox)
                            {
                                int index = GetControlIndex(checkBox.Name, "checkBox");
                                if (index != -1)
                                {
                                    TextBox optionTextBox = AddQuestion.Controls.Find($"optionTextBox{index}", true).FirstOrDefault() as TextBox;
                                    if (optionTextBox != null)
                                    {
                                        bool isCorrect = checkBox.Checked; 
                                        SaveAnswerToDb(db, questionId, optionTextBox.Text, isCorrect);
                                    }
                                }
                            }
                        }
                    }
                    else if (questionType == "Последовательность ответов")
                    {
                        TextBox sequenceTextBox = AddQuestion.Controls.OfType<TextBox>().LastOrDefault();
                        if (sequenceTextBox != null)
                        {
                            string[] answers = sequenceTextBox.Text.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                            foreach (var answer in answers)
                            {
                                SaveAnswerToDb(db, questionId, answer.Trim(), false);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении ответов: {ex.Message}");
                }
            }
        }

        private int GetControlIndex(string controlName, string prefix)
        {
            if (controlName.StartsWith(prefix))
            {
                string indexStr = controlName.Substring(prefix.Length);
                if (int.TryParse(indexStr, out int index))
                {
                    return index;
                }
            }
            return -1;
        }

        private void DeleteOldAnswersFromDb(DB db, int questionId)
        {
            using (var connection = db.GetConnection())
            {
                string query = "DELETE FROM Answers WHERE QuestionID = @QuestionID";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@QuestionID", questionId);
                    command.ExecuteNonQuery();
                }
            }
        }

        private void SaveAnswerToDb(DB dB, int questionId, string answerText, bool isCorrect)
        {
            using (DB db = new DB())
            {
                db.OpenConnection();
                string query = "INSERT INTO Answers (QuestionID, AnswerText, IsCorrect) VALUES (@QuestionID, @AnswerText, @IsCorrect)";
                using (SqlCommand command = new SqlCommand(query, db.GetConnection()))
                {
                    command.Parameters.AddWithValue("@QuestionID", questionId);
                    command.Parameters.AddWithValue("@AnswerText", answerText);
                    command.Parameters.AddWithValue("@IsCorrect", isCorrect);

                    command.ExecuteNonQuery();
                }
            }
        }

        [Obsolete]
        private void Save_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Сохранить тест, да или нет?", "Подтверждение", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                UpdateTestTable();
            }
            else
            {
                ClearData();
            }
        }

        [Obsolete]
        private void UpdateTestTable()
        {
            _adminForm.RefreshTestTable();

            this.Close();
        }

        [Obsolete]
        private void ClearData()
        {
            this.Close();
        }
    }
}
