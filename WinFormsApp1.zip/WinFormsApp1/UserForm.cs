﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class userForm : Form
    {
        private int userId;
        public userForm(int userId)
        {
            InitializeComponent();
            this.userId = userId;

            LoadData();
            Test.CellContentClick += Test_CellContentClick;
        }

        private void LoadData()
        {
            using (DB db = new DB())
            {
                try
                {
                    db.OpenConnection();

                    string queryTests = "SELECT * FROM Tests ORDER BY TestID";

                    SqlCommand command = new SqlCommand(queryTests, db.GetConnection());

                    SqlDataReader reader = command.ExecuteReader();

                    List<string[]> data = new List<string[]>();

                    while (reader.Read())
                    {
                        data.Add(new string[4]);

                        data[data.Count - 1][0] = reader[0].ToString();
                        data[data.Count - 1][1] = reader[1].ToString();
                        data[data.Count - 1][2] = reader[2].ToString();
                        data[data.Count - 1][3] = reader[3].ToString();
                    }

                    reader.Close();

                    db.CloseConnection();

                    foreach (string[] s in data)
                        Test.Rows.Add(s);
                }

                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void ReturnButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Test Test = new Test();
            Test.Show();
        }

        private void Test_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == Test.Columns["StartTest"].Index)
            {
                int testId = Convert.ToInt32(Test.Rows[e.RowIndex].Cells[0].Value);
                string testName = Test.Rows[e.RowIndex].Cells[1].Value.ToString();
                string subject = Test.Rows[e.RowIndex].Cells[2].Value.ToString();
                int questionCount = Convert.ToInt32(Test.Rows[e.RowIndex].Cells[3].Value);

                if (Application.OpenForms.OfType<RunTest>().Any())
                {
                    Application.OpenForms.OfType<RunTest>().First().Activate();
                }
                else
                {
                    this.Hide();
                    RunTest runTest = new RunTest(testId, testName, subject, questionCount, userId);
                    runTest.FormClosed += (s, args) => this.Show();
                    runTest.Show();
                }
            }
        }
    }
}
