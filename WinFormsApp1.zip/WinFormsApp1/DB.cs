﻿using System.Data.SqlClient;
using System;

namespace WinFormsApp1
{
    internal class DB : IDisposable
    {
        private readonly string connectionString = "Server=DESKTOP-E5P60FN;Database=Test;Integrated Security=True;";
        private SqlConnection connection;

        public DB()
        {
            connection = new SqlConnection(connectionString);
        }

        public void OpenConnection()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
                connection.Open();
        }

        public void CloseConnection()
        {
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
        }

        public SqlConnection GetConnection()
        {
            return connection;
        }

        public void Dispose()
        {
            CloseConnection();
            connection.Dispose();
        }
    }
}
