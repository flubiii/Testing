﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;
using MongoDB.Driver.Core.Configuration;

namespace WinFormsApp1
{
    public partial class AdminCreateForm : Form
    {
        private AdminForm _adminForm;
        public AdminCreateForm(AdminForm adminForm)
        {
            InitializeComponent();
            _adminForm = adminForm;

            this.btnImage.Click += new System.EventHandler(this.btnImage_Click);
            this.QuestionTest.Items.AddRange(new string[] { "Один ответ", "Несколько ответов", "Последовательность ответов" });
            this.QuestionTest.SelectedIndexChanged += ComboBoxQuestionTypes_SelectedIndexChanged;
        }

        private void ComboBoxQuestionTypes_SelectedIndexChanged(object sender, EventArgs e)
        {
            AddQuestion.Controls.Clear();
            string selectedType = QuestionTest.SelectedItem.ToString();

            Label questionLabel = new() { Text = "Введите вопрос:", AutoSize = true, Location = new Point(10, 20) };
            TextBox questionTextBox = new() { Width = 300, Location = new Point(10, 40) };
            AddQuestion.Controls.Add(questionLabel);
            AddQuestion.Controls.Add(questionTextBox);

            for (int i = 1; i <= 4; i++)
            {
                Label optionLabel = new() { Text = $"Введите вариант ответа {i}:", AutoSize = true, Location = new Point(10, 80 + (i - 1) * 70) };
                TextBox optionTextBox = new() { Name = $"optionTextBox{i}", Width = 300, Location = new Point(10, 100 + (i - 1) * 70) };

                if (selectedType == "Один ответ")
                {
                    RadioButton radioButton = new() { Name = $"radioButton{i}", Text = $"Вариант {i}", AutoSize = true, Location = new Point(325, 102 + (i - 1) * 70) };
                    AddQuestion.Controls.Add(radioButton);
                }
                if (selectedType == "Последовательность ответов")
                {

                }
                else if (selectedType == "Несколько ответов")
                {
                    CheckBox checkBox = new() { Name = $"checkBox{i}", Text = $"Вариант {i}", AutoSize = true, Location = new Point(325, 102 + (i - 1) * 70) };
                    AddQuestion.Controls.Add(checkBox);
                }

                AddQuestion.Controls.Add(optionLabel);
                AddQuestion.Controls.Add(optionTextBox);
            }

            if (selectedType == "Последовательность ответов")
            {
                Label sequenceLabel = new() { Text = "Введите последовательность (через запятую):", AutoSize = true, Location = new Point(10, 370) };
                TextBox sequenceTextBox = new() { Width = 300, Location = new Point(10, 390) };
                AddQuestion.Controls.Add(sequenceLabel);
                AddQuestion.Controls.Add(sequenceTextBox);
            }
        }

        [Obsolete]
        private void SaveQuestion_Click(object sender, EventArgs e)
        {
            string questionText = ((TextBox)AddQuestion.Controls[1]).Text;
            string questionType = QuestionTest.SelectedItem.ToString();

            int newTestID;

            using (DB db = new DB())
            {
                db.OpenConnection();

                string getMaxTestIdQuery = "SELECT ISNULL(MAX(TestID), 0) FROM Tests";
                using (SqlCommand command = new(getMaxTestIdQuery, db.GetConnection()))
                {
                    newTestID = (int)command.ExecuteScalar();
                }

                string insertQuestionQuery = "INSERT INTO Questions (TestID, QuestionText, QuestionType) OUTPUT INSERTED.QuestionID VALUES (@TestID, @QuestionText, @QuestionType)";
                int questionID;

                using (SqlCommand command = new(insertQuestionQuery, db.GetConnection()))
                {
                    command.Parameters.AddWithValue("@TestID", newTestID);
                    command.Parameters.AddWithValue("@QuestionText", questionText);
                    command.Parameters.AddWithValue("@QuestionType", questionType);
                    questionID = (int)command.ExecuteScalar();
                }

                string updateTestQuestionCountQuery = @"
                UPDATE Tests
                SET QuestionCount = (
                SELECT COUNT(*)
                FROM Questions
                WHERE Questions.TestID = Tests.TestID
                )
                WHERE TestID = @TestID";

                using (SqlCommand updateCommand = new(updateTestQuestionCountQuery, db.GetConnection()))
                {
                    updateCommand.Parameters.AddWithValue("@TestID", newTestID);
                    updateCommand.ExecuteNonQuery();
                }

                SaveAnswers(questionID, questionType, db);
            }

            AddQuestion.Controls.Clear();
            MessageBox.Show("Вопрос сохранен");
        }

        [Obsolete]
        private void SaveAnswers(int questionID, string questionType, DB db)
        {
            try
            {
                using (var connection = db.GetConnection())
                {
                    if (connection.State != ConnectionState.Open)
                    {
                        connection.Open();
                        Console.WriteLine("Соединение открыто");
                    }
                    if (questionType == "Один ответ" || questionType == "Несколько ответов")
                    {
                        foreach (Control control in AddQuestion.Controls)
                        {
                            if (control is RadioButton radioButton)
                            {
                                int index = int.Parse(radioButton.Name.Replace("radioButton", ""));
                                string textBoxName = $"optionTextBox{index}";
                                TextBox optionTextBox = AddQuestion.Controls.Find(textBoxName, true).FirstOrDefault() as TextBox;

                                if (optionTextBox != null)
                                {
                                    bool isChecked = radioButton.Checked;
                                    SaveAnswer(connection, questionID, optionTextBox.Text, isChecked);
                                }
                            }
                            else if (control is CheckBox checkBox)
                            {
                                int index = int.Parse(checkBox.Name.Replace("checkBox", ""));
                                string textBoxName = $"optionTextBox{index}";
                                TextBox optionTextBox = AddQuestion.Controls.Find(textBoxName, true).FirstOrDefault() as TextBox;

                                if (optionTextBox != null)
                                {
                                    bool isChecked = checkBox.Checked;
                                    SaveAnswer(connection, questionID, optionTextBox.Text, isChecked);
                                }
                            }
                        }
                    }
                    else if (questionType == "Последовательность ответов")
                    {
                        TextBox sequenceTextBox = AddQuestion.Controls.OfType<TextBox>().LastOrDefault();
                        if (sequenceTextBox != null)
                        {
                            string[] answers = sequenceTextBox.Text.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (var answer in answers)
                            {
                                SaveAnswer(connection, questionID, answer.Trim(), false);
                            }
                        }
                    }
                    if (PictureBox.Image != null)
                    {
                        byte[] imageBytes = ImageToByteArray(PictureBox.Image);
                        SaveImageToDatabase(connection, questionID, imageBytes);
                        PictureBox.Image = null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении ответов: {ex.Message}");
            }
        }

        private byte[] ImageToByteArray(Image imageIn)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                imageIn.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private void SaveImageToDatabase(SqlConnection connection, int questionID, byte[] imageBytes)
        {
            string query = "UPDATE Questions SET Image = @Image WHERE QuestionID = @QuestionID";
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                command.Parameters.AddWithValue("@Image", imageBytes);
                command.Parameters.AddWithValue("@QuestionID", questionID);
                command.ExecuteNonQuery();
            }
        }

        private void btnImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = @"C:";
                openFileDialog.Filter = "Image files (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp|All files (*.*)|*.*";
                openFileDialog.FilterIndex = 1;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;

                    PictureBox.Image = Image.FromFile(filePath);
                    PictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
                }
            }
        }

        [Obsolete]
        private void SaveAnswer(SqlConnection connection, int questionID, string answerText, bool isCorrect)
        {
            try
            {
                string saveAnswerQuery = "INSERT INTO Answers (QuestionID, AnswerText, isCorrect) VALUES (@QuestionID, @AnswerText, @isCorrect)";

                using (SqlCommand command = new SqlCommand(saveAnswerQuery, connection))
                {
                    command.Parameters.AddWithValue("@QuestionID", questionID);
                    command.Parameters.AddWithValue("@AnswerText", answerText);
                    command.Parameters.AddWithValue("@isCorrect", isCorrect);

                    command.ExecuteNonQuery();
                    Console.WriteLine("Ответ успешно сохранен");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении ответа: {ex.Message}");
            }
        }


        [Obsolete]
        private void Save_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Сохранить тест, да или нет?", "Подтверждение", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                UpdateTestTable();
            }
            else
            {
                ClearData();
            }
        }

        [Obsolete]
        private void UpdateTestTable()
        {
            _adminForm.RefreshTestTable();

            this.Close();
        }

        [Obsolete]
        private void ClearData()
        {
            using (DB db = new DB())
            {
                db.OpenConnection();

                string clearQuestionsQuery = "DELETE FROM Questions";
                string clearAnswersQuery = "DELETE FROM Answers";
                string clearTestsQuery = "DELETE FROM Tests";

                using (SqlCommand command1 = new(clearQuestionsQuery, db.GetConnection()))
                {
                    command1.ExecuteNonQuery();
                }
                using (SqlCommand command2 = new(clearAnswersQuery, db.GetConnection()))
                {
                    command2.ExecuteNonQuery();
                }
                using (SqlCommand command3 = new(clearTestsQuery, db.GetConnection()))
                {
                    command3.ExecuteNonQuery();
                }
            }

            this.Close();
        }
    }
}