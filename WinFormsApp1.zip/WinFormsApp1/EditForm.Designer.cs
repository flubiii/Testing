﻿namespace WinFormsApp1
{
    partial class EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditForm));
            QuestionsPanel = new Panel();
            Questions = new ComboBox();
            SaveQuestion = new Button();
            Save = new Button();
            QuestionTest = new ComboBox();
            AddQuestion = new Panel();
            MytoolTip = new ToolTip(components);
            QuestionsPanel.SuspendLayout();
            SuspendLayout();
            // 
            // QuestionsPanel
            // 
            QuestionsPanel.BackColor = SystemColors.ActiveBorder;
            QuestionsPanel.Controls.Add(Questions);
            QuestionsPanel.Controls.Add(SaveQuestion);
            QuestionsPanel.Controls.Add(Save);
            QuestionsPanel.Controls.Add(QuestionTest);
            QuestionsPanel.Location = new Point(-31, -21);
            QuestionsPanel.Name = "QuestionsPanel";
            QuestionsPanel.Size = new Size(1260, 96);
            QuestionsPanel.TabIndex = 9;
            // 
            // Questions
            // 
            Questions.FormattingEnabled = true;
            Questions.Location = new Point(43, 44);
            Questions.Name = "Questions";
            Questions.Size = new Size(374, 23);
            Questions.TabIndex = 0;
            MytoolTip.SetToolTip(Questions, "Выбор вопроса");
            // 
            // SaveQuestion
            // 
            SaveQuestion.FlatAppearance.BorderSize = 0;
            SaveQuestion.FlatStyle = FlatStyle.Flat;
            SaveQuestion.Image = (Image)resources.GetObject("SaveQuestion.Image");
            SaveQuestion.Location = new Point(642, 33);
            SaveQuestion.Name = "SaveQuestion";
            SaveQuestion.Size = new Size(45, 43);
            SaveQuestion.TabIndex = 9;
            MytoolTip.SetToolTip(SaveQuestion, "Сохранить вопрос");
            SaveQuestion.UseVisualStyleBackColor = true;
            SaveQuestion.Click += SaveQuestion_Click;
            // 
            // Save
            // 
            Save.FlatAppearance.BorderSize = 0;
            Save.FlatStyle = FlatStyle.Flat;
            Save.Image = (Image)resources.GetObject("Save.Image");
            Save.Location = new Point(1013, 33);
            Save.Name = "Save";
            Save.Size = new Size(45, 43);
            Save.TabIndex = 10;
            MytoolTip.SetToolTip(Save, "Сохранить тест");
            Save.UseVisualStyleBackColor = true;
            Save.Click += Save_Click;
            // 
            // QuestionTest
            // 
            QuestionTest.FormattingEnabled = true;
            QuestionTest.Location = new Point(436, 44);
            QuestionTest.Name = "QuestionTest";
            QuestionTest.Size = new Size(200, 23);
            QuestionTest.TabIndex = 9;
            MytoolTip.SetToolTip(QuestionTest, "Тип вопроса");
            // 
            // AddQuestion
            // 
            AddQuestion.AutoScroll = true;
            AddQuestion.BackColor = Color.Transparent;
            AddQuestion.Location = new Point(12, 93);
            AddQuestion.Name = "AddQuestion";
            AddQuestion.Size = new Size(771, 464);
            AddQuestion.TabIndex = 11;
            // 
            // EditForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1052, 664);
            Controls.Add(AddQuestion);
            Controls.Add(QuestionsPanel);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "EditForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Тестирование";
            QuestionsPanel.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel QuestionsPanel;
        private Button SaveQuestion;
        private Button Save;
        private ComboBox QuestionTest;
        private Panel AddQuestion;
        private ComboBox Questions;
        private ToolTip MytoolTip;
    }
}