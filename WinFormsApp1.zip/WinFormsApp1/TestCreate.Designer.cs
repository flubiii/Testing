﻿namespace WinFormsApp1
{
    partial class TestCreate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TestCreate));
            NameTest = new TextBox();
            ThemeTest = new TextBox();
            SaveTest = new Button();
            label1 = new Label();
            label2 = new Label();
            SuspendLayout();
            // 
            // NameTest
            // 
            NameTest.Location = new Point(12, 42);
            NameTest.Name = "NameTest";
            NameTest.Size = new Size(551, 23);
            NameTest.TabIndex = 0;
            NameTest.TabStop = false;
            // 
            // ThemeTest
            // 
            ThemeTest.Location = new Point(12, 111);
            ThemeTest.Name = "ThemeTest";
            ThemeTest.Size = new Size(277, 23);
            ThemeTest.TabIndex = 1;
            ThemeTest.TabStop = false;
            // 
            // SaveTest
            // 
            SaveTest.Location = new Point(263, 173);
            SaveTest.Name = "SaveTest";
            SaveTest.Size = new Size(75, 23);
            SaveTest.TabIndex = 2;
            SaveTest.Text = "OK";
            SaveTest.UseVisualStyleBackColor = true;
            SaveTest.Click += SaveTest_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label1.Location = new Point(12, 24);
            label1.Name = "label1";
            label1.Size = new Size(95, 15);
            label1.TabIndex = 3;
            label1.Text = "Название теста";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            label2.Location = new Point(12, 93);
            label2.Name = "label2";
            label2.Size = new Size(67, 15);
            label2.TabIndex = 4;
            label2.Text = "Тема теста";
            // 
            // TestCreate
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(575, 265);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(SaveTest);
            Controls.Add(ThemeTest);
            Controls.Add(NameTest);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "TestCreate";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Тестирование";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox NameTest;
        private TextBox ThemeTest;
        private Button SaveTest;
        private Label label1;
        private Label label2;
    }
}