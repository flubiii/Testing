﻿namespace WinFormsApp1
{
    partial class AdminCreateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminCreateForm));
            QuestionsPanel = new Panel();
            btnImage = new Button();
            SaveQuestion = new Button();
            Save = new Button();
            QuestionTest = new ComboBox();
            MytoolTip = new ToolTip(components);
            AddQuestion = new Panel();
            PictureBox = new PictureBox();
            QuestionsPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)PictureBox).BeginInit();
            SuspendLayout();
            // 
            // QuestionsPanel
            // 
            QuestionsPanel.BackColor = SystemColors.ActiveBorder;
            QuestionsPanel.Controls.Add(btnImage);
            QuestionsPanel.Controls.Add(SaveQuestion);
            QuestionsPanel.Controls.Add(Save);
            QuestionsPanel.Controls.Add(QuestionTest);
            QuestionsPanel.Location = new Point(-31, -21);
            QuestionsPanel.Name = "QuestionsPanel";
            QuestionsPanel.Size = new Size(1260, 96);
            QuestionsPanel.TabIndex = 8;
            // 
            // btnImage
            // 
            btnImage.FlatAppearance.BorderSize = 0;
            btnImage.FlatStyle = FlatStyle.Flat;
            btnImage.Image = (Image)resources.GetObject("btnImage.Image");
            btnImage.Location = new Point(249, 33);
            btnImage.Name = "btnImage";
            btnImage.Size = new Size(45, 43);
            btnImage.TabIndex = 11;
            MytoolTip.SetToolTip(btnImage, "Добавить изображение");
            btnImage.UseVisualStyleBackColor = true;
            btnImage.Click += btnImage_Click;
            // 
            // SaveQuestion
            // 
            SaveQuestion.FlatAppearance.BorderSize = 0;
            SaveQuestion.FlatStyle = FlatStyle.Flat;
            SaveQuestion.Image = (Image)resources.GetObject("SaveQuestion.Image");
            SaveQuestion.Location = new Point(300, 33);
            SaveQuestion.Name = "SaveQuestion";
            SaveQuestion.Size = new Size(45, 43);
            SaveQuestion.TabIndex = 9;
            MytoolTip.SetToolTip(SaveQuestion, "Сохранить вопрос");
            SaveQuestion.UseVisualStyleBackColor = true;
            SaveQuestion.Click += SaveQuestion_Click;
            // 
            // Save
            // 
            Save.FlatAppearance.BorderSize = 0;
            Save.FlatStyle = FlatStyle.Flat;
            Save.Image = (Image)resources.GetObject("Save.Image");
            Save.Location = new Point(1013, 33);
            Save.Name = "Save";
            Save.Size = new Size(45, 43);
            Save.TabIndex = 10;
            MytoolTip.SetToolTip(Save, "Сохранить тест");
            Save.UseVisualStyleBackColor = true;
            Save.Click += Save_Click;
            // 
            // QuestionTest
            // 
            QuestionTest.FormattingEnabled = true;
            QuestionTest.Location = new Point(43, 44);
            QuestionTest.Name = "QuestionTest";
            QuestionTest.Size = new Size(200, 23);
            QuestionTest.TabIndex = 9;
            MytoolTip.SetToolTip(QuestionTest, "Добавить вопрос");
            // 
            // MytoolTip
            // 
            MytoolTip.AutoPopDelay = 5000;
            MytoolTip.InitialDelay = 100;
            MytoolTip.ReshowDelay = 100;
            // 
            // AddQuestion
            // 
            AddQuestion.AutoScroll = true;
            AddQuestion.BackColor = Color.Transparent;
            AddQuestion.Location = new Point(12, 93);
            AddQuestion.Name = "AddQuestion";
            AddQuestion.Size = new Size(1028, 464);
            AddQuestion.TabIndex = 10;
            // 
            // PictureBox
            // 
            PictureBox.Location = new Point(569, 113);
            PictureBox.Name = "PictureBox";
            PictureBox.Size = new Size(400, 295);
            PictureBox.TabIndex = 11;
            PictureBox.TabStop = false;
            // 
            // AdminCreateForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1052, 664);
            Controls.Add(PictureBox);
            Controls.Add(AddQuestion);
            Controls.Add(QuestionsPanel);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Icon = (Icon)resources.GetObject("$this.Icon");
            MaximizeBox = false;
            Name = "AdminCreateForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Тестирование";
            QuestionsPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)PictureBox).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel QuestionsPanel;
        private ComboBox QuestionTest;
        private Button SaveQuestion;
        private Button Save;
        private ToolTip MytoolTip;
        private Panel AddQuestion;
        private Button btnImage;
        private PictureBox PictureBox;
    }
}