﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Org.BouncyCastle.Pqc.Crypto.Lms;

namespace WinFormsApp1
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();

            SetPlaceholder(LoginRegText, "Введите логин");
            SetPlaceholder(FirstNameRegText, "Введите имя");
            SetPlaceholder(LastNameRegText, "Введите фамилию");
            SetPlaceholder(PasswordRegText, "Введите пароль");
        }

        private void SetPlaceholder(TextBox textBox, string placeholder)
        {
            textBox.Text = placeholder;
            textBox.ForeColor = Color.Silver;
            textBox.GotFocus += (s, e) => RemovePlaceholder(textBox, placeholder);
            textBox.LostFocus += (s, e) => SetPlaceholderIfEmpty(textBox, placeholder);
        }

        private void RemovePlaceholder(TextBox textBox, string placeholder)
        {
            if (textBox.Text == placeholder)
            {
                textBox.Text = "";
                textBox.ForeColor = Color.Black;
            }
        }

        private void SetPlaceholderIfEmpty(TextBox textBox, string placeholder)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                textBox.Text = placeholder;
                textBox.ForeColor = Color.Silver;
            }
        }

        private bool ValidatePassword(string password)
        {
            if (password.Length < 8 || password.Length > 32)
            {
                MessageBox.Show("Пароль должен содержать от 8 до 32 символов.");
                return false;
            }

            if (!password.Any(char.IsLower))
            {
                MessageBox.Show("Пароль должен содержать хотя бы одну строчную букву.");
                return false;
            }

            if (!password.Any(char.IsUpper))
            {
                MessageBox.Show("Пароль должен содержать хотя бы одну заглавную букву.");
                return false;
            }

            if (!password.Any(char.IsDigit))
            {
                MessageBox.Show("Пароль должен содержать хотя бы одну цифру.");
                return false;
            }

            if (!password.Any(ch => !char.IsLetterOrDigit(ch)))
            {
                MessageBox.Show("Пароль должен содержать хотя бы один специальный символ.");
                return false;
            }

            return true;
        }

        [Obsolete]
        private void buttonR_Click(object sender, EventArgs e)
        {
            string loginReg = LoginRegText.Text.Trim();
            string passReg = PasswordRegText.Text.Trim();
            string firstnameReg = FirstNameRegText.Text.Trim();
            string lastnameReg = LastNameRegText.Text.Trim();

            if (loginReg == "Введите логин" || string.IsNullOrWhiteSpace(loginReg))
            {
                MessageBox.Show("Логин обязателен для заполнения.");
                return;
            }

            if (firstnameReg == "Введите имя" || string.IsNullOrWhiteSpace(firstnameReg))
            {
                MessageBox.Show("Имя обязательно для заполнения.");
                return;
            }

            if (lastnameReg == "Введите фамилию" || string.IsNullOrWhiteSpace(lastnameReg))
            {
                MessageBox.Show("Фамилия обязательна для заполнения.");
                return;
            }

            if (!ValidatePassword(passReg))
            {
                return;
            }

            using (DB db = new DB())
            {
                db.OpenConnection();

                using (SqlCommand checkUserCommand = new SqlCommand("SELECT COUNT(*) FROM Users WHERE Username = @login", db.GetConnection()))
                {
                    checkUserCommand.Parameters.Add("@login", SqlDbType.NVarChar).Value = loginReg;

                    int userCount = (int)checkUserCommand.ExecuteScalar();
                    if (userCount > 0)
                    {
                        MessageBox.Show("Пользователь с таким логином уже существует.");
                        return;
                    }
                }

                using (SqlCommand command = new SqlCommand("INSERT INTO Users (Username, Password, FirstName, LastName, Role) VALUES (@login, @pass, @fn, @ln, 'User');", db.GetConnection()))
                {
                    command.Parameters.Add("@login", SqlDbType.NVarChar).Value = loginReg;
                    command.Parameters.Add("@pass", SqlDbType.NVarChar).Value = passReg;
                    command.Parameters.Add("@fn", SqlDbType.NVarChar).Value = firstnameReg;
                    command.Parameters.Add("@ln", SqlDbType.NVarChar).Value = lastnameReg;
                    try
                    {
                        var result = command.ExecuteScalar();
                        if (result != null) 
                        {
                            MessageBox.Show("Аккаунт зарегистрирован");
                            this.Hide();
                            Test testForm = new Test();
                            testForm.Show();
                        }
                        else
                        {
                            MessageBox.Show("Аккаунт не зарегистрирован");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка: " + ex.Message);
                    }
                }
            }
        }

        private void ReturnIcon_Click(object sender, EventArgs e)
        {
            this.Hide();
            Test Test = new Test();
            Test.Show();
        }
    }
}
